import React from 'react';
// import { render } from 'react-dom';

// render()
// {
// const App = () =>{
//     return(
//   <>
//     <div>
//       <h1>My Login Page</h1><br></br>
//       <h1>UserName</h1><input type="text" placeholder="Enter UserName:"/>
//       <h1>Password</h1> <input type="text" placeholder="Password:"/>
//       <button>Submit</button>
//     </div>
//     </>
//   );
// }
// }

// export default App

import React from 'react';

const Login = () => {
  return(
    <div>
      <h1>hello form</h1>
    </div>
  )
}

export default Login